/**
 * Created by Owner on 2017/3/2.
 */
$(document).ready(function () {
    $(".postil").click(function(){
        $(".note1").fadeToggle();
    });
});